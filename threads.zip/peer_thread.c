/*
    Fichero:  mensafono.c

       Envia y recibe datos de un proceso similar en otra maquina utilizando
    el protocolo UDP/IP. Forma un datagrama con cada linea que el usuario 
    teclea y lo envia.
*/

#ifndef _WINSOCKAPI_
#include <winsock.h>
#endif

#include <stdio.h>
#include <conio.h>
#include <time.h>
#include <string.h>


/* Arranque de Winsock */
#define VERSION 0x0101
#define PRINCIPAL HIBYTE(VERSION)
#define RELEASE   LOBYTE(VERSION)
#define NUM_MIN_SOCKETS 1



#define PUERTO_SERVIDOR 10001

#define MAX_TRAMA 256

typedef struct
{
  unsigned char tipo;
  unsigned char l;
  long dia;
  long mes;
  long hora;
  long minutos;
  long segundos;
  char msg[MAX_TRAMA];
} T_TRAMA;

void fin_aplicacion(SOCKET sock, int error)
{
	if (sock != INVALID_SOCKET)
		closesocket(sock);
	WSACleanup();

	exit (error);
}



// Thread para atender los eventos del puerto
DWORD FAR PASCAL LecturaSocket( LPSTR lpData )
{
	fd_set lectura;
	SOCKET sock=*((SOCKET *)lpData);
	int fin=0;
	T_TRAMA t_in;
	int ns,nc;
	struct timeval timeout;



	do
	{
      FD_ZERO(&lectura);
      FD_SET(sock,&lectura);

	  timeout.tv_sec=0;
	  timeout.tv_usec=1000;

      ns=select(sock+1,&lectura,NULL,NULL,&timeout);
      if (ns == SOCKET_ERROR)
      {
        fprintf(stderr, "ERROR: Error en la llamada a SELECT\n");
        fin_aplicacion(sock,1);
      }
      else if(ns > 0)
      {
          if (FD_ISSET(sock,&lectura))   // leer datos del teclado
          {
			  nc=recv(sock,(char *)&t_in,sizeof(T_TRAMA),0);
              if (nc==SOCKET_ERROR)
              {
                 fprintf(stderr, "ERROR: Error en la lectura del socket");
                 fin_aplicacion(sock,1);
              }
              printf("Recibiendo -----> ");
              printf("\t %ld - %ld %ld : %ld : %ld -> %s\n",ntohl(t_in.dia),
                                                       ntohl(t_in.mes),
                                                       ntohl(t_in.hora),
                                                       ntohl(t_in.minutos),
                                                       ntohl(t_in.segundos),
                                                       t_in.msg);
              fin=fin||t_in.msg[0]=='$';
          }

	  }
	} while (!fin);
   
   return( TRUE ) ;
} // end of CommWatchProc()







int main(int argc, char *argv[])
{
   WSADATA wsaData;

   SOCKET sock=INVALID_SOCKET;
   int l_remoto;

   struct sockaddr_in local,remoto;
   struct hostent *host;

   int i;

   T_TRAMA t_in;
   T_TRAMA t_out;
   int ns,nc;
   char car='\0';
   struct tm *Curr_time;
   time_t tiempo;
   int fin=0;
   int error;
   u_short puerto_local;
   u_short puerto_remoto;
   HANDLE thread_hnd;
   int thread_id;



   if(argc!=4)
       {
       printf("Sintaxis:%s host_remoto puerto_local puerto_remoto\n",argv[0]);
       exit(1);
       }

   error=WSAStartup(VERSION,&wsaData);
   if (error != 0)
   {
	   fprintf(stderr,"Versi�n de Winsocket no v�lida\n");
	   exit(1);
   }

fprintf(stderr,"Winsock started\n");

  /* Crear socket en el host local*/

   sock=socket(AF_INET,SOCK_DGRAM,0);
   if (sock == INVALID_SOCKET)
       {
        fprintf(stderr,"Error: Abriendo socket\n");
        fin_aplicacion(sock,1);
       }

fprintf(stderr,"socket creado\n");

   local.sin_family=AF_INET;
   local.sin_addr.s_addr=htonl(INADDR_ANY);
   sscanf(argv[2],"%hud",&puerto_local);
   local.sin_port=htons(puerto_local);
printf("puerto local: %d\n",(int)puerto_local);
   if (bind(sock,(struct sockaddr *) &local,sizeof(struct sockaddr_in)) != 0)
   {
      error=GetLastError();
	  switch (error)
      {
	  case WSANOTINITIALISED:
		  fprintf(stderr,"Hay que llamar con exito a WSAStartup antes de bind\n");
		  break;
	  case WSAENETDOWN:
		  fprintf(stderr,"Error de red\n");
		  break;
	  case WSAEADDRINUSE:
		  fprintf(stderr,"La direcci�n ya est� siendo usada\n");
		  break;
      case WSAEFAULT:
		  fprintf(stderr,"La longitud indicada es demasiado peque�a\n");
		  break;
	  case WSAEINPROGRESS:
		  fprintf(stderr,"Hay una llamada bloqueante en proceso\n");
		  break;
	  case WSAEAFNOSUPPORT:
		  fprintf(stderr,"Este protocolo no soporta la familia indicada\n");
		  break;
	  case WSAEINVAL:
		  fprintf(stderr,"El socket ya ha sido nombrado\n");
		  break;
	  case WSAENOBUFS:
		  fprintf(stderr,"Demasiadas conexiones, no hay buffers disponibles\n");
		  break;
	  case WSAENOTSOCK:
		  fprintf(stderr,"El descriptor no es un socket\n");
		  break;
	  }
	  fin_aplicacion(sock,1);
   }
fprintf(stderr,"socket nombrado\n");

   /* Definir el host remoto */

   remoto.sin_family = AF_INET;
   host = gethostbyname(argv[1]);
   if (host == 0)
   {
	  fprintf(stderr,"Error:%s es un host desconocido\n",argv[1]);
	  fin_aplicacion(sock,1);
   }
   
   memcpy(&remoto.sin_addr.s_addr,host->h_addr,host->h_length);
   sscanf(argv[3],"%hud",&puerto_remoto);
printf("puerto remoto: %d\n",(int)puerto_remoto);
   remoto.sin_port = htons(puerto_remoto);
   l_remoto=sizeof(struct sockaddr_in);

   if (connect(sock,(struct sockaddr *)&remoto,l_remoto)== SOCKET_ERROR)
   {
	   fprintf(stderr, "ERROR: Error en la escritura del socket");
	   fin_aplicacion(sock,1);
   }
printf("c: %d\n",'\n');
fprintf(stderr,"socket conectado\n");


      // Crear un thread secundario para vigilar los eventos
      if (NULL == (thread_hnd =
                      CreateThread( (LPSECURITY_ATTRIBUTES) NULL,
                                    0,
                                    (LPTHREAD_START_ROUTINE) LecturaSocket,
                                    (LPVOID) &sock,
                                    0, &thread_id )))
      {
		fin_aplicacion(sock,1);
      }





   t_out.l=0;

   do
   {

	  // Comprobar lectura del teclado
	  if (_kbhit())
	  {
		  t_out.msg[t_out.l]=_getch();
		  printf("%c(%d)",t_out.msg[t_out.l],t_out.msg[t_out.l]);
		  if ( (t_out.msg[t_out.l]==13) || (t_out.l == (MAX_TRAMA-2)) )
		  {

			  if (t_out.msg[t_out.l]==13)
			  {
				  t_out.l++;
			  }
			  t_out.msg[t_out.l]='\0';
			  t_out.l++;
			  time(&tiempo);
			  Curr_time=localtime(&tiempo);
              tiempo=time(NULL);
              t_out.dia=htonl((long)Curr_time->tm_mday);
              t_out.mes=htonl((long)(Curr_time->tm_mon+1));
              t_out.hora=htonl((long)Curr_time->tm_hour);
              t_out.minutos=htonl((long)Curr_time->tm_min);
              t_out.segundos=htonl((long)Curr_time->tm_sec);
			  /* Enviar la trama */
fprintf(stderr,"Enviada trama\n");
			  nc=send(sock,(char *)&t_out,sizeof(T_TRAMA),0);
              if (nc==SOCKET_ERROR)
              {
                 fprintf(stderr, "ERROR: Error en la escritura del socket");
                 fin_aplicacion(sock,1);
              }
			  t_out.l=0;
              fin=t_out.msg[0]=='$';

		  }
		  else
			  t_out.l++;
	  }
   } while (! fin);

   TerminateThread(thread_hnd,0);
   fin_aplicacion(sock,0);
   return (0);
}
