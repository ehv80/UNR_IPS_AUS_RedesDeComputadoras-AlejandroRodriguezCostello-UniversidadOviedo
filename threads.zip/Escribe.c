#include "peer.h"

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>
#include <string.h>

// Thread para atender la escritura del socket
DWORD FAR PASCAL EscribeSocket( LPSTR lpData )
{
	CONEXION *conexion=((CONEXION *)lpData);
	SOCKET sock=conexion->sock;
	int fin=0;
	int nc;
	time_t hora;

	do
	{
		switch (conexion->reenviar)
		{
		case 0:
			if (conexion->ack_pendiente)
			{
				conexion->reenviar=-1;
				memset(&conexion->t_out,0,sizeof(T_TRAMA));
				conexion->t_out.tipo=0;
				conexion->t_out.seq=conexion->seq_envio;
				conexion->t_out.ack=conexion->seq_esperado;
				conexion->t_out.chksum=CalculaChksum(&conexion->t_out);
				nc=send(sock,(char *)&conexion->t_out,sizeof(T_TRAMA),0);
				if (nc==SOCKET_ERROR)
				{
					fprintf(stderr, "ERROR: Error en la escritura del socket");
					fin_aplicacion(conexion,1);
				}
				conexion->timeout=time(NULL);
				conexion->ack_pendiente=0;
				conexion->reenviar=0;
			}
			break;
		case 1:
			fprintf(stderr,"Enviando trama\n");
			conexion->reenviar=-1;
			nc=send(sock,(char *)&conexion->t_out,sizeof(T_TRAMA),0);
			if (nc==SOCKET_ERROR)
			{
				fprintf(stderr, "ERROR: Error en la escritura del socket");
				fin_aplicacion(conexion,1);
			}
			conexion->timeout=time(NULL);
			conexion->fin_escritura= ((conexion->fin_escritura) || (conexion->t_out.msg[0]=='$'));
			conexion->reenviar=2;
			break;
		case 2:
			if (conexion->ack_pendiente)
			{
				hora=time(NULL);
				conexion->reenviar=-1;
				conexion->t_out.ack=conexion->seq_esperado;
				conexion->t_out.chksum=0;
				conexion->t_out.chksum=CalculaChksum(&conexion->t_out);
				conexion->ack_pendiente=0;
				conexion->reenviar=2;
			}
			break;
		}
	} while (! (conexion->fin_lectura && conexion->fin_escritura));
	
	return( TRUE ) ;
}



