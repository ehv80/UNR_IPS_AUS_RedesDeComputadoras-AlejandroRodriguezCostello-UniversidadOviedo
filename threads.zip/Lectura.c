#include "peer.h"

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>
#include <string.h>

// Thread para atender la lectura del socket
DWORD FAR PASCAL LecturaSocket( LPSTR lpData )
{
	CONEXION *conexion =((CONEXION *)lpData);
	SOCKET sock=conexion->sock;
	int fin=0;
	int nc;
	struct timeval timeout;
	fd_set lectura;
	unsigned short chksum=0;
	time_t hora;
	int aux;
	
	do
	{
		timeout.tv_sec=0;
		timeout.tv_usec=50000;

		FD_ZERO(&lectura);
		FD_SET(sock,&lectura);

		if (select(sock+1,&lectura,NULL,NULL,&timeout)>0)
		{
			// leer el mensaje recibido
			nc=recv(sock,(char *)&conexion->t_in,sizeof(T_TRAMA),0);
			if (nc==SOCKET_ERROR)
			{
				fprintf(stderr, "ERROR: Error en la lectura del socket");
				fin_aplicacion(conexion,1);
			}
			fprintf(stderr,"Leida una trama\n");
			chksum=conexion->t_in.chksum;
			conexion->t_in.chksum=(unsigned short)0;
			fprintf(stderr,"tipo: %d, n ack: %d, n seq: %d\n",conexion->t_in.tipo,conexion->t_in.ack,conexion->seq_envio);
			fprintf(stderr,"n seq_recibido: %d, n esperado: %d\n",conexion->t_in.seq,conexion->seq_esperado);

			if ( ((conexion->t_in.seq == conexion->seq_esperado)|| (conexion->t_in.tipo==0))
				&& (chksum == CalculaChksum(&conexion->t_in)))
			{
				if (conexion->t_in.ack-1 == conexion->seq_envio)
				{
					conexion->reenviar=-1;
					conexion->seq_envio++;
					conexion->num_reenvios=0;
					memset(&conexion->t_out,0,sizeof(T_TRAMA));
					/* conexion->ack_pendiente=0; */
					conexion->reenviar=0;
				}
				if ( (conexion->t_in.tipo & 0x01) && (conexion->t_in.seq == conexion->seq_esperado))
				{
					aux=conexion->reenviar;
					conexion->reenviar=-1;
					conexion->ack_pendiente=1;
					fprintf(stderr,"Marcado ack pendiente\n");
					conexion->seq_esperado++;
					printf("Recibiendo -----> ");
					printf("\t %ld - %ld %ld : %ld : %ld -> %s\n",ntohl(conexion->t_in.dia),
						ntohl(conexion->t_in.mes),
						ntohl(conexion->t_in.hora),
						ntohl(conexion->t_in.minutos),
						ntohl(conexion->t_in.segundos),
						conexion->t_in.msg);
					conexion->fin_lectura=conexion->t_in.msg[0]=='$';
					conexion->reenviar=aux;
					memset(&conexion->t_in,0,sizeof(T_TRAMA));
				}
			}
			else
			{
				fprintf(stderr,"trama rechazada");
				if (conexion->t_out.tipo==0x00)
				{
					fprintf(stderr,", ack pendiente");
					conexion->ack_pendiente=1;
				}
				fprintf(stderr,"\n");
			}
		}
		/* Comprobar el time_out */
		hora=time(NULL);
		if ( ((hora-(conexion->timeout))>15) && (conexion->num_reenvios>=0) 
			&&  (conexion->reenviar==2) )
		{
			while (conexion->reenviar == -1);

			conexion->reenviar=-1;
			fprintf(stderr,"Reenviando trama por tout\n");
			conexion->num_reenvios--;
			conexion->timeout=hora;
			conexion->reenviar=1;
		}
		if ( (conexion->num_reenvios<0) &&  (conexion->reenviar==2) )
			fin_aplicacion(conexion,1);

	} while (!(conexion->fin_lectura && conexion->fin_escritura));
	
	return( TRUE ) ;
}
