#ifndef _WINSOCKAPI_
#include <winsock.h>
#endif

#include <time.h>

/* Arranque de Winsock */
#define VERSION 0x0101
#define PRINCIPAL HIBYTE(VERSION)
#define RELEASE   LOBYTE(VERSION)
#define NUM_MIN_SOCKETS 1

#define MAX_TRAMA 256

typedef struct
{
  unsigned char tipo;
  unsigned long seq;
  unsigned long ack;
  unsigned char l;
  long dia;
  long mes;
  long hora;
  long minutos;
  long segundos;
  char msg[MAX_TRAMA];
  unsigned short chksum;
} T_TRAMA;


typedef struct
{
	SOCKET sock;
	T_TRAMA t_in;
	T_TRAMA t_out;
    struct sockaddr_in local;
	struct sockaddr_in remoto;

	unsigned long seq_envio;
	unsigned long seq_esperado;

	time_t timeout;

	HANDLE th_hnd_envia;
	unsigned long th_id_envia;
	HANDLE th_hnd_recibe;
	unsigned long th_id_recibe;

	int reenviar;
	int num_reenvios;
	int ack_pendiente;
	int fin_escritura;
	int fin_lectura;
} CONEXION;

void fin_aplicacion(CONEXION *conexion, int error);
void crear_conexion(CONEXION *conexion, unsigned short local, char *destino, unsigned short remoto );
int enviar_trama(T_TRAMA *t_out, CONEXION *conexion);
unsigned short CalculaChksum(T_TRAMA *trama);
DWORD FAR PASCAL LecturaSocket( LPSTR lpData );
DWORD FAR PASCAL EscribeSocket( LPSTR lpData );

