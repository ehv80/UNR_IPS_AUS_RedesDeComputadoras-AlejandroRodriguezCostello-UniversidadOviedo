/*
Fichero:  mensafono.c

  Envia y recibe datos de un proceso similar en otra maquina utilizando
  el protocolo UDP/IP. Forma un datagrama con cada linea que el usuario 
  teclea y lo envia.
*/
#include "peer.h"

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>
#include <string.h>


void fin_aplicacion(CONEXION *conexion, int error)
{
	TerminateThread(conexion->th_hnd_envia,0);
	TerminateThread(conexion->th_hnd_recibe,0);
	if (conexion->sock != INVALID_SOCKET)
		closesocket(conexion->sock);
	WSACleanup();
	exit (error);
}

void crear_conexion(CONEXION *conexion, unsigned short local, char *destino, unsigned short remoto )
{
	int l_remoto;
	struct hostent *host;
	int error;

	conexion->th_hnd_envia=0;
	conexion->th_id_envia=0;
	conexion->th_hnd_recibe=0;
	conexion->th_id_recibe=0;

	conexion->seq_envio=0;
	conexion->seq_esperado=0;

	conexion->fin_escritura=0;
	conexion->fin_lectura=0;

	conexion->reenviar=0;
	conexion->num_reenvios=0;
	conexion->ack_pendiente=0;

	memset(&conexion->t_out,0,sizeof(T_TRAMA));
	memset(&conexion->t_in,0,sizeof(T_TRAMA));

	conexion->sock=socket(AF_INET,SOCK_DGRAM,0);
	if (conexion->sock == INVALID_SOCKET)
	{
        fprintf(stderr,"Error: Abriendo socket\n");
        fin_aplicacion(conexion,1);
	}
	
	fprintf(stderr,"socket creado\n");
	
	conexion->local.sin_family=AF_INET;
	conexion->local.sin_addr.s_addr=htonl(INADDR_ANY);
	conexion->local.sin_port=htons(local);
	
	fprintf(stderr,"puerto local: %d\n",(int)local);
	
	if (bind(conexion->sock,(struct sockaddr *) &conexion->local,sizeof(struct sockaddr_in)) != 0)
	{
		error=WSAGetLastError();
		switch (error)
		{
		case WSANOTINITIALISED:
			fprintf(stderr,"Hay que llamar con exito a WSAStartup antes de bind\n");
			break;
		case WSAENETDOWN:
			fprintf(stderr,"Error de red\n");
			break;
		case WSAEADDRINUSE:
			fprintf(stderr,"La direcci�n ya est� siendo usada\n");
			break;
		case WSAEFAULT:
			fprintf(stderr,"La longitud indicada es demasiado peque�a\n");
			break;
		case WSAEINPROGRESS:
			fprintf(stderr,"Hay una llamada bloqueante en proceso\n");
			break;
		case WSAEAFNOSUPPORT:
			fprintf(stderr,"Este protocolo no soporta la familia indicada\n");
			break;
		case WSAEINVAL:
			fprintf(stderr,"El socket ya ha sido nombrado\n");
			break;
		case WSAENOBUFS:
			fprintf(stderr,"Demasiadas conexiones, no hay buffers disponibles\n");
			break;
		case WSAENOTSOCK:
			fprintf(stderr,"El descriptor no es un socket\n");
			break;
		}
		fin_aplicacion(conexion,1);
	}
	
	fprintf(stderr,"socket nombrado\n");
	
	/* Definir el host remoto */
	
	conexion->remoto.sin_family = AF_INET;
	host = gethostbyname(destino);
	if (host == 0)
	{
		fprintf(stderr,"Error:%s es un host desconocido\n",destino);
		fin_aplicacion(conexion,1);
	}
	
	memcpy(&conexion->remoto.sin_addr.s_addr,host->h_addr,host->h_length);
	
	fprintf(stderr,"puerto remoto: %d\n",(int)remoto);
	
	conexion->remoto.sin_port = htons(remoto);
	l_remoto=sizeof(struct sockaddr_in);
	
	if (connect(conexion->sock,(struct sockaddr *)&conexion->remoto,l_remoto)== SOCKET_ERROR)
	{
		fprintf(stderr, "ERROR: Error en la escritura del socket");
		fin_aplicacion(conexion,1);
	}
	
	fprintf(stderr,"socket conectado\n");

	/* Lanzar los threads */
	if (NULL == (conexion->th_hnd_envia=CreateThread( (LPSECURITY_ATTRIBUTES) NULL,
		0,
		(LPTHREAD_START_ROUTINE) EscribeSocket,
		(LPVOID) conexion,
		0, &conexion->th_id_envia )))
	{
		fin_aplicacion(conexion,1);
	}
	if (NULL == (conexion->th_hnd_recibe=CreateThread( (LPSECURITY_ATTRIBUTES) NULL,
		0,
		(LPTHREAD_START_ROUTINE) LecturaSocket,
		(LPVOID) conexion,
		0, &conexion->th_id_recibe )))
	{
		fin_aplicacion(conexion,1);
	}

}


int enviar_trama(T_TRAMA *t_out, CONEXION *conexion)
{
	switch (conexion->reenviar)
	{
	case 0:
		conexion->reenviar=-1;
		// copiar t_out en conexion->t_out
		memcpy(&conexion->t_out,t_out,sizeof(T_TRAMA));
		conexion->t_out.seq=conexion->seq_envio;
		conexion->t_out.ack=conexion->seq_esperado;
		conexion->t_out.tipo= (unsigned char) ((unsigned char)0x01) ;
		conexion->t_out.chksum=CalculaChksum(&conexion->t_out);
	
		conexion->num_reenvios=5;
		conexion->reenviar=1;

		memset(t_out,0,sizeof(T_TRAMA));
		return 0;
		break;
	}
	return 1;
}




unsigned short CalculaChksum(T_TRAMA *trama)
{
	unsigned short *tramaInt;
	int len=(sizeof(T_TRAMA)-sizeof(unsigned short))/sizeof(unsigned short);
	int i=0;
	unsigned long chksum=0;
	
	tramaInt=(unsigned short *)trama;
	
	for (i=0; i<len; i++)
		chksum += tramaInt[i];

	return ((unsigned short)(chksum % (unsigned short)0xFFFF));
}






int main(int argc, char *argv[])
{
	WSADATA wsaData;
	
	CONEXION conexion;
	T_TRAMA t_out;	
	
	char car='\0';
	struct tm *Curr_time;
	time_t tiempo;
	int fin=0;
	int error;
	u_short puerto_local;
	char destino[256];
	u_short puerto_remoto;
	
	memset(&t_out,0,sizeof(T_TRAMA));

	if(argc==4)
	{
		sscanf(argv[1],"%hud\n",&puerto_local);
		strcpy(destino,argv[2]);
		sscanf(argv[3],"%hud\n",&puerto_remoto);
	}
	else
	{
		printf("puerto_local: "); scanf("%hud\n",&puerto_local);
		printf("maquina remota: "); scanf("%s",destino);
		printf("puerto_remoto: "); scanf("%hud\n",&puerto_remoto);
	}
	
	
	error=WSAStartup(VERSION,&wsaData);
	
	if (error != 0)
	{
		fprintf(stderr,"Versi�n de Winsocket no v�lida\n");
		exit(1);
	}
	
	fprintf(stderr,"Winsock started\n");

	crear_conexion(&conexion,puerto_local,destino,puerto_remoto);

	fprintf(stderr,"Comienza la lectura del teclado\n");
	t_out.l=0;
	do
	{
		
		// Comprobar lectura del teclado
		if (_kbhit())
		{
			t_out.msg[t_out.l]=(char)_getch();
			printf("%c",t_out.msg[t_out.l]);
			if ( (t_out.msg[t_out.l]==13) || (t_out.l == (MAX_TRAMA-2)) )
			{
				
				if (t_out.msg[t_out.l]==13)
				{
					printf("\n");
					t_out.l++;
				}
				t_out.msg[t_out.l]='\0';
				t_out.l++;
				time(&tiempo);
				Curr_time=localtime(&tiempo);
				t_out.dia=htonl((long)Curr_time->tm_mday);
				t_out.mes=htonl((long)(Curr_time->tm_mon+1));
				t_out.hora=htonl((long)Curr_time->tm_hour);
				t_out.minutos=htonl((long)Curr_time->tm_min);
				t_out.segundos=htonl((long)Curr_time->tm_sec);
				/* Enviar la trama */
				
				while(enviar_trama(&t_out,&conexion));
				fprintf(stderr,"Trama enviada\n");

				fin=t_out.msg[0]=='$';
				
			}
			else
				t_out.l++;
		}
	} while (! conexion.fin_escritura);
	
	/* Esperar a que finalice la recepcion */
	while(! conexion.fin_lectura);

	fin_aplicacion(&conexion,0);
	return (0);
}
